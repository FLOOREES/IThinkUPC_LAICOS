from .models import Member

print('Member.objects.all()')